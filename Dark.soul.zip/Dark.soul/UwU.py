from os import *
from os import system, remove
import os
from sys import *
from time import *
R = '\x1b[1;31m'
G = '\x1b[1;32m'
Y = '\x1b[1;33m'
C = '\x1b[1;36m'
W = '\x1b[1;37m'
print (Y + '       _______')
print (Y + '      / _   _ \\ ')
print (Y + '     /' + R + ' (.)' + Y + '_' + R + '(.)' + Y + ' \\ ')
print (Y + '    (___________)')
print (Y + '     \\`-V-|-V-`/')
print (Y + '      \\   |   /')
print (Y + '       \\  ^  /')
print (Y + '        \\    \\ ')
print (Y + '         \\    `-_')
print (Y + '          `-_    -_')
print (Y + '             -_    -_')
print (Y + '             _-    _-')
print (Y + '          _-    _-')
print (Y + '        _-    _-')
print (Y + '      _-    _-')
print (Y + '      -_    -_')
print (Y + '        -_    -_')
print (Y + '          -_    -_')
print (Y + '            -_    -_')
print (Y + '            _-    _-')
print (Y + '  ,-=:_-_-_-_ _ _-_-_-_:=-.')
print (Y + ' /=I=I=I=I=I=I=I=I=I=I=I=I=\\ ')
print (Y + '|=I=I=I=I=I=I=I=I=I=I=I=I=I=|')
print (Y + '|I=I=I=I=I=I=I=I=I=I=I=I=I=I|')
print (Y + '\\=I=I=I=I=I=I=I=I=I=I=I=I=I=/')
print (Y + ' \\=I=I=I=I=I=I=I=I=I=I=I=I=/')
print (Y + '  \\=I=I=I=I=I=I=I=I=I=I=I=/')
print (Y + '   \\=I=I=I=I=I=I=I=I=I=I=/')
print (Y + '    \\=I=I=I=I=I=I=I=I=I=/')
print (Y + '     `=================')
print (G + '[' + R + '1' + G + ']' + W + '==' + G + '[' + Y + 'Decrypt bash script' + G + ']')
system('sleep 0.1')
print (G + '[' + R + '2' + G + ']' + W + '==' + G + '[' + Y + 'Encrypt bash script' + G + ']')
system('sleep 0.1')
print ( G +"["+ R +"0" + G +"]"+ W +"=="+ G +"["+ Y +"Exit program"+ G +"]")

print(" ")
mroid=str(input(R +"              ●~"+ G +"Enter Number "+ R +"~》 "+ G))
if  mroid=="0":

    system('clear')
    print(G)
    system('figlet GoodBye')
    print(R +"="*70)

    exit()
if mroid == '1':
    system('clear')
    system('python3 yt.py')
    system('python3 Darksoul/Dark.py')
    print (R + 'Please transfer the script to my file... :D')
if mroid == '2':
    system('clear')
print (R + 'Please transfer the script to my file... :D')
system('python3 teo.py')
system('python3 Darksoul/Dark.py')

