ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

Welcome to the shit_k_pop tool :)

ــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ

#######

Shit_k_pop

#######

What does this tool do?

This tool installs the best AHT.Hacker hack tool, creates a link to hack a phone camera, runs the automatic Instagram notification bot, installs an inshackle, and decrypts files in the bash language

To run the shit_k_pop tool, you must follow these steps:

########

Commands

########

1)cd Mr.Ali

2)chmod 777 *

3)python shit_k_pop.py

~~~~~~~~~~~¤~~~~~~~~~~~

Thank you very much for using the. Shit_k_pop tool ฅ^•ﻌ•^ฅ# shit_k_pop

