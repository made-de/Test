z="
";Gz='pkg ';Jz='et -';Cz='apk ';Pz='3m"';Dz='add ';Az='clea';Qz='et I';Oz='[1;3';Hz='inst';Rz='Love';Mz='tf "';Ez='figl';Lz='prin';Sz='You ';Nz='\x1b';Bz='r';Iz='all ';Kz='y';Fz='etf';Tz=':D';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$z$Gz$Hz$Iz$Ez$Jz$Kz$z$Az$Bz$z$Lz$Mz$Nz$Oz$Pz$z$Ez$Qz$Rz$Sz$Tz"
printf "\033[1;31m"
figlet BeyBey
