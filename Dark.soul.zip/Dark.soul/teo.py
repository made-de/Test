from os import system,remove

R='\033[1;31m'

G='\033[1;32m'

Y='\033[1;33m'

C='\033[1;36m'

W='\033[1;37m'



system('apt-get install nodejs -y')
system('npm install -g bash-obfuscate')
system('clear')
print (Y +'ILOVEYOUILOVEYOUILOVEYOUILOVEYOUILOVEYOUILOVEYOUILOVEY\nILOVEYOUILO' + R + '******' + Y + 'VEYOU' + R + '******' + Y + 'ILOVEYOUILOVEYOUILOVEYOUEY\nILOVEYOU' + R + '***********' + Y + 'I' + R + '***********' + Y + 'LOVEYOUILOVEYOUILOVEYOU\nOUIUI' + R + '*******************************' + Y + 'VEYOUILOVEYOUILOVE\nYOUI' + R + '**********************************' + Y + 'LOVEYOUILOVEYOUI\nIL' + R + '*************************************' + Y + 'OVEYOUILOVEYOUI\nL' + R + '*************' + Y + 'I' + R + '**' + Y + 'LOVE' + R + '**' + Y + 'YOU' + R + '*' + Y + '!' + R + '************' + Y + 'OVEYOUILOVEYOU\nI' + R + '***************************************' + Y + 'LOVEYOUILOVEYO\nU' + R + '***************************************' + Y + 'ILOVEYOUILOVEY\nOU' + R + '*************************************' + Y + 'ILOVEYOUILOVEYO\nUIL' + R + '***********************************' + Y + 'OVEYOUILOVEYOUIL\nOVEYO' + R + '*******************************' + Y + 'ULOVEYOUILOVEYOUIL\nOVEYOUI' + R + '****************************' + Y + 'LOVEYOUILOVEYOUILOV\nEYOUILOVE' + R + '***********************' + Y + 'YOUILOVEYOUILOVEYOUILO\nVEYOUILOVEYOU' + R + '*****************' + Y + 'ILOVEYOUILOVEYOUILOVEYOU\nILOVEYOUILOVEYO' + R + '*************' + Y + 'LOVEYOUILOVEYOUILOVEYOUILO\nUILOVEYOUILOVEYOU' + R + '*********' + Y + 'LOVEYOUILOVEYOUILOVEYOUILOVE\nLOVEYOUILOVEYOUILOV' + R + '*****' + Y + 'ILOVEYOUILOVEYOUILOVEYOUILOVEY\nEYOUILOVEYOUILOVEYOU' + R + '***' + Y + 'YOULOVEYOUILOVEYOUILOVEYOUILOVE\nVEYOUILOVEYOUILOVEYOU' + R + '*' + Y + 'VEYOUILOVEYOUILOVEYOUILOVEYOUILO\nOVEYOUILOVEYOUILOVEYOUILOVEYOUILOVEYOUILOVEYOUILOVEYOU')
ask = input('Enter file bash > ')
a = 'bash-obfuscate ' + ask + ' -o enc.sh'
system(a)
print ('done {enc.sh}')
