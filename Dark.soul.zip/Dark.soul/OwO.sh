clear
python3 UwU.py
